const url = 'https://dad-jokes.p.rapidapi.com/random/joke'
const options = {
  method: 'GET',
  headers: {
    'X-RapidAPI-Key': '04b90ddc1cmsh2a59e35236b1632p1253fcjsnb4ae01b2d2c0',
    'X-RapidAPI-Host': 'dad-jokes.p.rapidapi.com',
  },
}

const getRandomJokes = async () => {
  try {
    const response = await fetch(url, options)
    const result = await response.json()

    if (result?.success) {
      console.log(result)
      const paragraph = document.createElement('p')
      console.log(result?.body[0]?.punchline)
      paragraph.textContent = result?.body[0]?.punchline
      const mainBody = document.getElementById('main')
      mainBody.appendChild(paragraph)
    }
  } catch (error) {
    console.error(error)
  }
}
//getRandomJokes()

const generateButton = document.getElementById('btn')
generateButton.addEventListener('click', () => {
  getRandomJokes()
})
